package com.changefacefast

import ai.onnxruntime.*
import android.content.Context
import android.graphics.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class Swapper(ctx: Context) {
    private val env = OrtEnvironment.getEnvironment()
    private val swap: OrtSession
    private val emb: OrtSession
    private val emap: FloatArray
    private val mask = FloatArray(128 * 128)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        val o1 = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
        val o2 = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
        swap = env.createSession(Models.file(ctx, Models.SWAP).absolutePath, o1)
        emb = env.createSession(Models.file(ctx, Models.EMB).absolutePath, o2)
        val bytes = ctx.assets.open("emap.bin").readBytes()
        emap = FloatArray(512 * 512)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(emap)
        for (y in 0 until 128) for (x in 0 until 128) {
            val dx = (x - 64f) / 50f; val dy = (y - 66f) / 58f
            val r = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            mask[y * 128 + x] = ((1f - r) / 0.3f).coerceIn(0f, 1f)
        }
    }

    private fun chw(b: Bitmap, mean: Float, scale: Float): FloatArray {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val o = FloatArray(3 * w * h)
        for (i in px.indices) {
            val c = px[i]
            o[i] = (((c shr 16) and 255) - mean) * scale
            o[w * h + i] = (((c shr 8) and 255) - mean) * scale
            o[2 * w * h + i] = ((c and 255) - mean) * scale
        }
        return o
    }

    /** Latent vector for the source face (512). */
    fun latent(photo: Bitmap, face: Face): FloatArray {
        val a = Geo.align(photo, face.pts, 112)
        val input = chw(a, 127.5f, 1f / 127.5f)
        val t = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, 3, 112, 112))
        val r = emb.run(mapOf(emb.inputNames.first() to t))
        val e = FloatArray(512); (r[0] as OnnxTensor).floatBuffer.get(e)
        r.close(); t.close()
        norm(e)
        val l = FloatArray(512)
        for (i in 0 until 512) { val v = e[i]; for (j in 0 until 512) l[j] += v * emap[i * 512 + j] }
        norm(l)
        return l
    }

    private fun norm(v: FloatArray) {
        var s = 0f; for (x in v) s += x * x
        s = Math.sqrt(s.toDouble()).toFloat().coerceAtLeast(1e-8f)
        for (i in v.indices) v[i] /= s
    }

    /** Swap face in-place on a mutable frame. */
    fun swapFace(frame: Bitmap, f: Face, latent: FloatArray) {
        val a = Geo.align(frame, f.pts, 128)
        val input = chw(a, 0f, 1f / 255f)
        val t1 = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, 3, 128, 128))
        val t2 = OnnxTensor.createTensor(env, FloatBuffer.wrap(latent), longArrayOf(1, 512))
        val r = swap.run(mapOf("target" to t1, "source" to t2))
        val o = FloatArray(3 * 128 * 128); (r[0] as OnnxTensor).floatBuffer.get(o)
        r.close(); t1.close(); t2.close()
        val n = 128 * 128
        val px = IntArray(n)
        for (i in 0 until n) {
            val rr = (o[i] * 255f).toInt().coerceIn(0, 255)
            val gg = (o[n + i] * 255f).toInt().coerceIn(0, 255)
            val bb = (o[2 * n + i] * 255f).toInt().coerceIn(0, 255)
            val al = (mask[i] * 255f).toInt()
            px[i] = (al shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
        val res = Bitmap.createBitmap(px, 128, 128, Bitmap.Config.ARGB_8888)
        val m = Geo.sim(f.pts, Geo.tpl(128))
        val inv = Matrix()
        if (m.invert(inv)) Canvas(frame).drawBitmap(res, inv, paint)
        res.recycle(); a.recycle()
    }
}
