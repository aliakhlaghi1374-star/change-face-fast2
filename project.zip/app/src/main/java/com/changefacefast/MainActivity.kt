package com.changefacefast

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var facesBox: LinearLayout
    private lateinit var startBtn: Button
    private lateinit var cancelBtn: Button
    private var video: VideoProc? = null
    private var scan: Scan? = null
    private val photos = HashMap<Int, Bitmap>()
    private val previews = HashMap<Int, ImageView>()
    @Volatile private var cancelled = false
    @Volatile private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun say(s: String) = ui.post { status.text = s }
    private fun prog(p: Int, max: Int = 100) = ui.post { bar.max = max; bar.progress = p }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val sv = ScrollView(this); sv.addView(root); setContentView(sv)
        root.addView(TextView(this).apply { text = "Change Face Fast"; textSize = 26f; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "فقط برای افرادی که رضایت داده‌اند استفاده کنید. جعل هویت دیگران غیراخلاقی و اغلب غیرقانونی است."
            setTextColor(Color.RED); setPadding(0, dp(8), 0, dp(8))
        })
        root.addView(Button(this).apply { text = "انتخاب ویدیو"; setOnClickListener { if (!busy) pick("video/*", 1) } })
        status = TextView(this).apply { text = "یک ویدیو انتخاب کنید."; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); root.addView(bar)
        facesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(facesBox)
        startBtn = Button(this).apply { text = "شروع تعویض چهره"; visibility = View.GONE; setOnClickListener { start() } }
        root.addView(startBtn)
        cancelBtn = Button(this).apply { text = "لغو"; visibility = View.GONE; setOnClickListener { cancelled = true } }
        root.addView(cancelBtn)
    }

    private fun pick(type: String, code: Int) {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType(type).addCategory(Intent.CATEGORY_OPENABLE), code)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 1) analyze(uri)
        else if (req >= 100) {
            val i = req - 100
            try {
                val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
                val s = 1600f / maxOf(bmp.width, bmp.height)
                val bb = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true) else bmp
                photos[i] = bb.copy(Bitmap.Config.ARGB_8888, false)
                previews[i]?.setImageBitmap(photos[i])
            } catch (e: Exception) { say("خطا در خواندن عکس: " + e.message) }
        }
    }

    private fun analyze(uri: Uri) {
        busy = true; cancelled = false
        facesBox.removeAllViews(); startBtn.visibility = View.GONE; photos.clear(); previews.clear()
        say("در حال تحلیل ویدیو و شمارش چهره‌ها…")
        Thread {
            try {
                val v = VideoProc(this, uri)
                val s = v.scan({ cancelled }) { k, n -> prog(k, n) }
                video = v; scan = s
                ui.post { showFaces() }
            } catch (e: Throwable) { say("خطا: " + e) }
            busy = false
        }.start()
    }

    private fun showFaces() {
        val s = scan
        if (s == null || s.faces.isEmpty()) { say("هیچ چهره‌ای در ویدیو پیدا نشد."); return }
        say("تعداد چهره‌های پیدا شده: ${s.faces.size}\nبرای هر چهره یک عکس انتخاب کنید (چهره‌ای که عکس ندارد دست‌نخورده می‌ماند).")
        s.faces.forEachIndexed { i, f ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
            val r = Rect(f.box); val pad = r.width() / 4
            r.inset(-pad, -pad); r.intersect(0, 0, s.frame.width, s.frame.height)
            val th = Bitmap.createBitmap(s.frame, r.left, r.top, r.width(), r.height())
            row.addView(ImageView(this).apply { setImageBitmap(th); layoutParams = LinearLayout.LayoutParams(dp(90), dp(90)); scaleType = ImageView.ScaleType.CENTER_CROP })
            row.addView(TextView(this).apply { text = "  ←  "; textSize = 22f })
            val box = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(90), dp(90)); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.LTGRAY); setOnClickListener { pick("image/*", 100 + i) } }
            previews[i] = box; row.addView(box)
            row.addView(Button(this).apply { text = "انتخاب عکس چهره ${i + 1}"; setOnClickListener { pick("image/*", 100 + i) } })
            facesBox.addView(row)
        }
        startBtn.visibility = View.VISIBLE
    }

    private fun start() {
        if (busy) return
        if (photos.isEmpty()) { say("حداقل یک عکس انتخاب کنید."); return }
        busy = true; cancelled = false; cancelBtn.visibility = View.VISIBLE; startBtn.visibility = View.GONE
        Thread {
            try {
                val total = Models.SWAP.size + Models.EMB.size
                var base = 0L
                for (m in listOf(Models.SWAP, Models.EMB)) {
                    if (Models.file(this, m).length() != m.size) {
                        Models.download(this, m) { got ->
                            say("دانلود مدل‌ها (فقط بار اول): " + ((base + got) * 100 / total) + "٪")
                            prog(((base + got) * 100 / total).toInt())
                        }
                    }
                    base += m.size
                }
                say("بارگذاری مدل…")
                val sw = Swapper(this)
                val s = scan!!
                val lat = ArrayList<FloatArray?>()
                for (i in s.faces.indices) {
                    val p = photos[i]
                    if (p == null) { lat.add(null); continue }
                    val fs = Geo.detect(p)
                    if (fs.isEmpty()) { say("در عکس چهره ${i + 1} چهره‌ای پیدا نشد؛ نادیده گرفته شد."); lat.add(null); continue }
                    val big = fs.maxByOrNull { it.box.width() * it.box.height() }!!
                    lat.add(sw.latent(p, big))
                }
                say("در حال پردازش ویدیو…")
                val out = video!!.process(s.faces, lat, sw, { cancelled }) { i, n ->
                    prog(i, n); say("پردازش فریم $i از $n")
                }
                if (out == null) say("لغو شد.") else { save(out); say("تمام شد. ویدیو در پوشه Movies/ChangeFaceFast ذخیره شد.") }
            } catch (e: Throwable) { say("خطا: " + e + "\n" + e.stackTrace.take(4).joinToString("\n")) }
            busy = false
            ui.post { cancelBtn.visibility = View.GONE; startBtn.visibility = View.VISIBLE }
        }.start()
    }

    private fun save(f: java.io.File) {
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "CFF_" + System.currentTimeMillis() + ".mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ChangeFaceFast")
        }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
    }
}
