package com.changefacefast

import android.content.Context
import android.graphics.Bitmap
import android.media.*
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

class Scan(val frame: Bitmap, val faces: List<Face>)

class VideoProc(val ctx: Context, val uri: Uri) {
    private val mmr = MediaMetadataRetriever().apply { setDataSource(ctx, uri) }
    val durationUs = (mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L) * 1000
    var fps = 30f

    init {
        val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)!!.startsWith("video/") && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                fps = try { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() } catch (e: Exception) { try { f.getFloat(MediaFormat.KEY_FRAME_RATE) } catch (e2: Exception) { 30f } }
                if (fps < 1f) fps = 30f
            }
        }
        ex.release()
    }

    fun frameAt(us: Long): Bitmap? {
        var b = mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST) ?: return null
        var w = b.width; var h = b.height
        val mx = maxOf(w, h)
        if (mx > 1920) { val s = 1920f / mx; w = (w * s).toInt(); h = (h * s).toInt() }
        w = w and 1.inv(); h = h and 1.inv()
        if (w != b.width || h != b.height) b = Bitmap.createScaledBitmap(b, w, h, true)
        return b.copy(Bitmap.Config.ARGB_8888, true)
    }

    /** Sample frames and find the one with the most faces. */
    fun scan(cancel: () -> Boolean, prog: (Int, Int) -> Unit): Scan? {
        val n = ((durationUs / 1_000_000L).toInt()).coerceIn(1, 60)
        var best: Scan? = null
        for (k in 0 until n) {
            if (cancel()) return null
            prog(k, n)
            val b = frameAt(durationUs * (2 * k + 1) / (2 * n)) ?: continue
            val fs = Geo.detect(b)
            if (best == null || fs.size > best.faces.size) best = Scan(b, fs.sortedBy { it.cx })
        }
        return best
    }

    fun process(
        slots: List<Face>, latents: List<FloatArray?>, swapper: Swapper,
        cancel: () -> Boolean, prog: (Int, Int) -> Unit
    ): File? {
        val outFile = File(ctx.cacheDir, "out.mp4"); outFile.delete()
        val total = (durationUs / 1_000_000.0 * fps).toInt().coerceAtLeast(1)
        val first = frameAt(0) ?: return null
        val w = first.width; val h = first.height
        val bitrate = (w.toLong() * h * 4).coerceIn(1_000_000L, 20_000_000L).toInt()
        val fmt = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, Math.round(fps))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType("video/avc")
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // audio
        var aex: MediaExtractor? = null; var aTrack = -1; var aFmt: MediaFormat? = null
        try {
            val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { ex.selectTrack(i); aFmt = f; aTrack = mux.addTrack(f); aex = ex; break }
            }
            if (aex == null) ex.release()
        } catch (e: Exception) { aex = null; aTrack = -1 }

        val info = MediaCodec.BufferInfo()
        var vTrack = -1; var started = false
        fun drain(end: Boolean) {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, if (end) 10000 else 0)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!end) return else continue }
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { vTrack = mux.addTrack(enc.outputFormat); mux.start(); started = true; continue }
                if (i < 0) continue
                val buf = enc.getOutputBuffer(i)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    mux.writeSampleData(vTrack, buf, info)
                }
                enc.releaseOutputBuffer(i, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }

        val last = FloatArray(slots.size * 2) { if (it % 2 == 0) slots[it / 2].cx else slots[it / 2].cy }
        var prev: Bitmap = first
        val px = IntArray(w * h)
        try {
            for (i in 0 until total) {
                if (cancel()) { enc.stop(); enc.release(); mux.release(); return null }
                prog(i, total)
                val us = (i * 1_000_000.0 / fps).toLong()
                var fr = if (i == 0) first else frameAt(us)
                if (fr == null || fr.width != w || fr.height != h) fr = prev.copy(Bitmap.Config.ARGB_8888, true)
                val faces = Geo.detect(fr)
                // greedy nearest matching of detected faces to slots
                val pairs = ArrayList<Triple<Float, Int, Int>>()
                for (s in slots.indices) for (f in faces.indices) {
                    val dx = faces[f].cx - last[2 * s]; val dy = faces[f].cy - last[2 * s + 1]
                    pairs.add(Triple(Math.hypot(dx.toDouble(), dy.toDouble()).toFloat(), s, f))
                }
                pairs.sortBy { it.first }
                val us2 = HashSet<Int>(); val uf = HashSet<Int>()
                for ((d, s, f) in pairs) {
                    if (d > 0.4f * w) break
                    if (s in us2 || f in uf) continue
                    us2.add(s); uf.add(f)
                    last[2 * s] = faces[f].cx; last[2 * s + 1] = faces[f].cy
                    val l = latents[s]
                    if (l != null) try { swapper.swapFace(fr, faces[f], l) } catch (e: Exception) { }
                }
                // encode
                fr.getPixels(px, 0, w, 0, 0, w, h)
                var idx = enc.dequeueInputBuffer(10000)
                while (idx < 0) { drain(false); idx = enc.dequeueInputBuffer(10000) }
                fill(enc.getInputImage(idx)!!, px, w, h)
                enc.queueInputBuffer(idx, 0, w * h * 3 / 2, us, 0)
                drain(false)
                if (prev !== first && prev !== fr) prev.recycle()
                prev = fr
            }
            var idx = enc.dequeueInputBuffer(10000)
            while (idx < 0) { drain(false); idx = enc.dequeueInputBuffer(10000) }
            enc.queueInputBuffer(idx, 0, 0, total * 1_000_000L / fps.toLong().coerceAtLeast(1), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)

            if (aex != null && aTrack >= 0) {
                val maxSz = if (aFmt!!.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) aFmt.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) else (1 shl 20)
                val bb = ByteBuffer.allocate(maxSz.coerceAtLeast(1 shl 16))
                val bi = MediaCodec.BufferInfo()
                while (true) {
                    val n = aex.readSampleData(bb, 0)
                    if (n < 0) break
                    bi.set(0, n, aex.sampleTime, aex.sampleFlags)
                    mux.writeSampleData(aTrack, bb, bi)
                    aex.advance()
                }
            }
        } finally {
            try { enc.stop() } catch (e: Exception) {}
            enc.release()
            try { mux.stop() } catch (e: Exception) {}
            mux.release()
            aex?.release()
        }
        return outFile
    }

    private fun fill(img: Image, px: IntArray, w: Int, h: Int) {
        val yp = img.planes[0]; val up = img.planes[1]; val vp = img.planes[2]
        val yb = yp.buffer; val ub = up.buffer; val vb = vp.buffer
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                yb.put(y * yp.rowStride + x * yp.pixelStride, (0.257f * r + 0.504f * g + 0.098f * b + 16f).toInt().coerceIn(0, 255).toByte())
                if ((y and 1) == 0 && (x and 1) == 0) {
                    val u = (-0.148f * r - 0.291f * g + 0.439f * b + 128f).toInt().coerceIn(0, 255).toByte()
                    val v = (0.439f * r - 0.368f * g - 0.071f * b + 128f).toInt().coerceIn(0, 255).toByte()
                    ub.put((y / 2) * up.rowStride + (x / 2) * up.pixelStride, u)
                    vb.put((y / 2) * vp.rowStride + (x / 2) * vp.pixelStride, v)
                }
            }
        }
    }
}
