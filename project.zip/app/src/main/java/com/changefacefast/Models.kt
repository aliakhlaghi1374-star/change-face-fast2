package com.changefacefast

import android.content.Context
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL

object Models {
    class M(val name: String, val url: String, val size: Long)
    val SWAP = M("inswapper_128_fp16.onnx", "https://huggingface.co/hacksider/deep-live-cam/resolve/main/inswapper_128_fp16.onnx", 277680638L)
    val EMB = M("w600k_r50.onnx", "https://huggingface.co/public-data/insightface/resolve/main/models/buffalo_l/w600k_r50.onnx", 174383860L)

    fun file(c: Context, m: M) = File(c.filesDir, m.name)
    fun ready(c: Context) = file(c, SWAP).length() == SWAP.size && file(c, EMB).length() == EMB.size

    /** Resumable download. Retries until complete. */
    fun download(c: Context, m: M, onProg: (Long) -> Unit) {
        val out = file(c, m)
        if (out.length() == m.size) return
        val part = File(c.filesDir, m.name + ".part")
        var tries = 0
        while (part.length() < m.size) {
            if (++tries > 200) throw RuntimeException("دانلود ناموفق: " + m.name)
            try {
                val have = part.length()
                val con = URL(m.url).openConnection() as HttpURLConnection
                con.connectTimeout = 30000; con.readTimeout = 30000
                if (have > 0) con.setRequestProperty("Range", "bytes=$have-")
                val code = con.responseCode
                if (code != 200 && code != 206) { Thread.sleep(2000); continue }
                val raf = RandomAccessFile(part, "rw")
                if (code == 200) raf.setLength(0) else raf.seek(have)
                val ins = con.inputStream
                val buf = ByteArray(1 shl 16)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    raf.write(buf, 0, n)
                    onProg(raf.filePointer)
                }
                raf.close(); ins.close()
            } catch (e: Exception) {
                Thread.sleep(2000)
            }
        }
        part.renameTo(out)
    }
}
