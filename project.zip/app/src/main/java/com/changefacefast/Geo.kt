package com.changefacefast

import android.graphics.*
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark

/** pts: 5 points (x,y)*5 = leftEye,rightEye,nose,mouthLeft,mouthRight in image order. */
class Face(val pts: FloatArray, val box: Rect) {
    val cx get() = box.exactCenterX()
    val cy get() = box.exactCenterY()
}

object Geo {
    val TPL = floatArrayOf(38.2946f, 51.6963f, 73.5318f, 51.5014f, 56.0252f, 71.7366f, 41.5493f, 92.3655f, 70.7299f, 92.2041f)

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setMinFaceSize(0.04f)
            .build()
    )

    fun detect(b: Bitmap): List<Face> {
        val res = Tasks.await(detector.process(InputImage.fromBitmap(b, 0)))
        val out = ArrayList<Face>()
        for (f in res) {
            val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position ?: continue
            val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position ?: continue
            val nb = f.getLandmark(FaceLandmark.NOSE_BASE)?.position ?: continue
            val ml = f.getLandmark(FaceLandmark.MOUTH_LEFT)?.position ?: continue
            val mr = f.getLandmark(FaceLandmark.MOUTH_RIGHT)?.position ?: continue
            val e = if (le.x <= re.x) listOf(le, re) else listOf(re, le)
            val m = if (ml.x <= mr.x) listOf(ml, mr) else listOf(mr, ml)
            out.add(Face(floatArrayOf(e[0].x, e[0].y, e[1].x, e[1].y, nb.x, nb.y, m[0].x, m[0].y, m[1].x, m[1].y), f.boundingBox))
        }
        return out
    }

    /** least-squares similarity transform src->dst */
    fun sim(s: FloatArray, d: FloatArray): Matrix {
        val n = s.size / 2
        var msx = 0f; var msy = 0f; var mdx = 0f; var mdy = 0f
        for (i in 0 until n) { msx += s[2 * i]; msy += s[2 * i + 1]; mdx += d[2 * i]; mdy += d[2 * i + 1] }
        msx /= n; msy /= n; mdx /= n; mdy /= n
        var num1 = 0f; var num2 = 0f; var den = 0f
        for (i in 0 until n) {
            val sx = s[2 * i] - msx; val sy = s[2 * i + 1] - msy
            val dx = d[2 * i] - mdx; val dy = d[2 * i + 1] - mdy
            num1 += sx * dx + sy * dy; num2 += sx * dy - sy * dx; den += sx * sx + sy * sy
        }
        val a = num1 / den; val b = num2 / den
        val tx = mdx - (a * msx - b * msy); val ty = mdy - (b * msx + a * msy)
        val m = Matrix()
        m.setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f))
        return m
    }

    fun tpl(size: Int) = FloatArray(10) { TPL[it] * size / 112f }

    fun align(src: Bitmap, pts: FloatArray, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, sim(pts, tpl(size)), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
